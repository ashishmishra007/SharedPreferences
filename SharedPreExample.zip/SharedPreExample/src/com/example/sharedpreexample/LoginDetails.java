package com.example.sharedpreexample;

import java.util.logging.Logger;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.Log;

/**
 * This Singleton class handles to store data corresponding login details which
 * are stored in {@link SharedPreferences}
 */
public class LoginDetails {

	private SharedPreferences sh;

	private LoginDetails() {

	}

	private LoginDetails(Context mContext) {
		sh = PreferenceManager.getDefaultSharedPreferences(mContext);

	}

	private static LoginDetails instance = null;

	/**
	 * 
	 * @param mContext
	 * @return {@link LoginDetails}
	 */
	public synchronized static LoginDetails getInstance(Context mContext) {

		if (instance == null) {
			instance = new LoginDetails(mContext);
		}
		return instance;
	}

	/**
	 * @return the username
	 */
	public String getUsername() {
		return sh.getString("username", "");
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return sh.getString("email_id", "");
	}

	/**
	 * @return the count
	 */
	public String getCount() {
		return sh.getString("count", "");
	}

	/**
	 * @param username
	 *            the username to set
	 */
	public void setUsername(String username) {
		sh.edit().putString("username", username).commit();
	}

	/**
	 * @param email
	 *            the email to set
	 */
	public void setEmail(String email) {
		sh.edit().putString("email_id", email).commit();
	}

	/**
	 * @param count
	 *            the count to set
	 */
	public void setCount(String count) {
		sh.edit().putString("count", count).commit();
	}

	public void clear() {
		sh.edit().clear().commit();
	}

	/**
	 * 
	 * @return check Login
	 */
	public boolean isLogin() {
		return !TextUtils.isEmpty(getUserid().trim());
	}

	/**
	 * 
	 * @return {@link String} Simply returns <b>userid</b> whatever is stored in
	 *         shared preferences with key <code>userid</code>.
	 * 
	 */
	public String getUserid() {
		return sh.getString("userid", "");
	}

	public void setUserid(String userid) {
//		Logger.i(Logger.TAG, ""+userid);
	Log.d("UID", ""+userid);
		sh.edit().putString("userid", userid).commit();
	}

	public boolean isShare() {
		return sh.getBoolean("isshare", false);
	}

	public void setShareComments(boolean isShare) {
		sh.edit().putBoolean("isshare", isShare).commit();
	}
}
